//#include "Buffer.h"
//#include "Node.h"
//#include "input.h"
//
//void INTER_Prediction(BUFFER* img, Data* file, uint8 p_size, uint32 ul_recon, uint32 ul_org)
//{
//
//}